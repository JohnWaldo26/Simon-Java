/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.simon;

/**
 *
 * @author johnwaldo
 */
import java.util.concurrent.TimeUnit;
public class Simon {

    public static void main(String[] args) throws InterruptedException {
        Name name= new Name();
        name.setVisible(true); 
        
    }
}
